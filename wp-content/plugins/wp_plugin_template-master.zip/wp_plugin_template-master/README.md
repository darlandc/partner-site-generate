wp_plugin_template
==================

A plugin template