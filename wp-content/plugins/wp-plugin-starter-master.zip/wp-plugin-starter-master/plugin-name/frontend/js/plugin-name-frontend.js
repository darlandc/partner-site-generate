(function ($) {
  'use strict';

  /**
   * Prints Hello world! to the console
   */
  var helloWorld = function () {
    // console.log('Hello world!');
  };

  $(document).ready(function () {
    helloWorld();
  });

})(jQuery);
